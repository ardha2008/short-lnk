<?php

/**
 * @author Ardha-PC
 * @copyright 2014
 */

header('Location:id');

?>