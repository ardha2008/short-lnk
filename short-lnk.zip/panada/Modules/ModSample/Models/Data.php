<?php
namespace Modules\ModSample\Models;

class Data {
    
    public function hello(){
        
        return 'Hello world from ';
    }
}